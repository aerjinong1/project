package core;

public class Person {
}
