package thread;

public class ThreadJMM {

    private volatile static boolean initData;


    private static void refresh() {
        System.out.println("change data");
        initData = true;
    }


    private static void loadData() {
        while (!initData) {
        }

        System.out.println("数据initData被改变-----");
    }

    //主线程
    public static void main(String[] args) {
        //t1
        new Thread(new Runnable() {
            @Override
            public void run() {
                loadData();
            }
        }, "t1").start();


        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //t2
        new Thread(new Runnable() {
            @Override
            public void run() {
                refresh();
            }
        }, "t2").start();


    }

}
