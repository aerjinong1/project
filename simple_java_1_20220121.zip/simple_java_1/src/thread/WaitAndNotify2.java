package thread;

public class WaitAndNotify2 {

    private static boolean flag = true;

    private static int count = 0;


    public static class Add100 {
        public synchronized void add1() throws InterruptedException {
            for (int i = 0; i < 50; i++) {
                while (flag) {
//                    System.out.println("add1 wait before");
                    wait();
//                    System.out.println("add1 wait after");
                }

                System.out.println("add1 add----->" + (++count));
                flag = !flag;
                notify();
                notifyAll();
            }
        }

        public synchronized void add2() throws InterruptedException {
            for (int i = 0; i < 50; i++) {
                while (!flag) {
//                    System.out.println("add2 wait before");
                    wait();
//                    System.out.println("add2 wait after");
                }

                System.out.println("add2 add----->" + (++count));
                flag = !flag;
                notify();
            }
        }
    }


    public static void main(String[] args) {
        Add100 add100 = new Add100();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    add100.add1();
                } catch (InterruptedException e) {
                    System.out.println("thread interrupt");
                }
            }
        }).start();


        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    add100.add2();
                } catch (InterruptedException e) {
                    System.out.println("thread interrupt");
                }
            }
        }).start();
    }
}
