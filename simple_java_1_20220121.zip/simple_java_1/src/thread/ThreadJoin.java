package thread;

public class ThreadJoin {
    private static int i = 0;

    public static class ThreadAdd extends Thread {
        @Override
        public void run() {
            for (; i < 1000000000; i++) ;
        }


        //主线程
        public static void main(String[] args) throws InterruptedException {
            //子线程
            ThreadAdd threadAdd = new ThreadAdd();
            threadAdd.start();
            threadAdd.join();

            System.out.println(i);
        }
    }

}
