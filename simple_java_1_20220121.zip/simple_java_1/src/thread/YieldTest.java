package thread;

public class YieldTest {

    public static void main(String[] args) {
        Yield y1 = new Yield();
        Yield y2 = new Yield();
        Yield y3 = new Yield();

        y1.start();
        y2.start();
        y3.start();
    }

}

//继承Thread
class Yield extends Thread {

    public Yield() {

    }

    public Yield(String name) {
        super(name);
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        for (int i = 0; i < 100; i++) {
            System.out.println(Thread.currentThread().getName() + ":  " + i);
            if (i % 20 == 0) {
                System.out.println(Thread.currentThread().getName() + ": " + i + "  yield一下");
                Thread.yield();
            }
        }
    }

}
