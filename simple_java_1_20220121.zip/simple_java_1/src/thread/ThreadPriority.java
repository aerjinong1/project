package thread;

public class ThreadPriority {
    static class PrimeRun implements Runnable {
        public void run() {
            System.out.println(Thread.currentThread().getName() + "priority::" +
                    Thread.currentThread().getPriority());
            System.out.println(Thread.currentThread().getName() + " Run begin");
            for (int i = 0; i < 10; i++) {
                System.out.println(Thread.currentThread().getName() + "::" + i);
            }
            System.out.println(Thread.currentThread().getName() + " Run end");
        }
    }

    public static void main(String[] args) {
        System.out.println(Thread.currentThread().getName() + " begin");
        Thread p4 = new Thread(new PrimeRun());
        Thread p6 = new Thread(new PrimeRun());
        p4.setName("P4");
        p4.setPriority(1);
        p6.setName("P6");
        p6.setPriority(6);
        p4.start();
        p6.start();
        System.out.println(Thread.currentThread().getName() + " end");
    }
}
