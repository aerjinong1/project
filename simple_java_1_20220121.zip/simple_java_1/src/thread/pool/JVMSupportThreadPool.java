package thread.pool;

import java.util.concurrent.*;

public class JVMSupportThreadPool {

    public static void main(String[] args) {

        ExecutorService singleThreadExecutor = Executors.newSingleThreadExecutor();
        ExecutorService newCachedThreadPool = Executors.newCachedThreadPool();
        ExecutorService newFixedThreadPool = Executors.newFixedThreadPool(5);
        ScheduledExecutorService newScheduledThreadPool = Executors.newScheduledThreadPool(5);
//
        TestPoolRunnable testPoolRunnable = new TestPoolRunnable();
//        for (int i = 0; i < 10; i++) {
//            singleThreadExecutor.submit(testPoolRunnable);
//        }
//        singleThreadExecutor.shutdown();


//        for (int i = 0; i < 10; i++) {
//            newCachedThreadPool.submit(testPoolRunnable);
//        }
//        newCachedThreadPool.shutdown();
//
//        for (int i = 0; i < 10; i++) {
//            newFixedThreadPool.submit(testPoolRunnable);
//        }
//        newFixedThreadPool.shutdown();
////
        for (int i = 0; i < 10; i++) {
//            newScheduledThreadPool.scheduleWithFixedDelay(testPoolRunnable, 0, 2, TimeUnit.SECONDS);
            newScheduledThreadPool.scheduleAtFixedRate(testPoolRunnable, 0, 2, TimeUnit.SECONDS);
            newScheduledThreadPool.submit(testPoolRunnable);
        }
        newScheduledThreadPool.shutdown();

        //TODO:Explain it
//        try {
//            newScheduledThreadPool.shutdown();
//            if (newScheduledThreadPool.awaitTermination(1, TimeUnit.SECONDS)) {
//                newScheduledThreadPool.shutdownNow();
//            }
//        } catch (InterruptedException e) {
//            System.out.println("awaitTermination interrupted: " + e);
//            newScheduledThreadPool.shutdownNow();
//        }
//    }

    }
}
