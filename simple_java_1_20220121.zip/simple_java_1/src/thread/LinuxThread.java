package thread;

public class LinuxThread extends Thread{

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName());
        try {
            sleep(100000000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        for (int i=0;i<4;i++){
            new LinuxThread().start();
        }
    }
}
