package thread;

public class ThreadMain {

    public static void main(String[] args) {
        Thread1 thread1 = new Thread1();
        thread1.start();
//        thread1.run();
        //这是安排给线程的事情
//        Thread2 thread2 = new Thread2();
//        //这事将安排好的事情分给线程去做
//        Thread thread = new Thread(thread2);
//        //启动线程去运行
//        thread.start();
////        new Thread();
////        thread2.run();
        System.out.println(Thread.currentThread().getName());
    }
}
