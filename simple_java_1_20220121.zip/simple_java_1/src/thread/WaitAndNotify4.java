package thread;

public class WaitAndNotify4 extends Thread {

//    @Override
//    public void run() {
//        System.out.println(Thread.currentThread().getName());
//    }
//
//    public static void main(String[] args) throws InterruptedException {
//        WaitAndNotify4 a = new WaitAndNotify4();
//        a.setName("A");
//        WaitAndNotify4 b = new WaitAndNotify4();
//        b.setName("B");
//        WaitAndNotify4 c = new WaitAndNotify4();
//        c.setName("C");
//        for (int i = 0; i < 5; i++) {
//           a.start();
//           a.join();
//           b.start();
//           b.join();
//           c.start();
//           c.join();
//        }
//    }

    private int flag = 0;

    public synchronized void a() {
        for (int i = 0; i < 5; i++) {
            while (flag != 0) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("A");
            flag = 1;
            notifyAll();
        }
    }

    public synchronized void b() {
        for (int i = 0; i < 5; i++) {
            while (flag != 1) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("B");
            flag = 2;
            notifyAll();
        }
    }


    public synchronized void c() {
        for (int i = 0; i < 5; i++) {
            while (flag != 2) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("C");
            flag = 0;
            notifyAll();
        }
    }


    public static void main(String[] args) {
        WaitAndNotify4 lock = new WaitAndNotify4();

        new Thread(new Runnable() {
            @Override
            public void run() {
                lock.a();
            }
        }).start();


        new Thread(new Runnable() {
            @Override
            public void run() {
                lock.b();
            }
        }).start();


        new Thread(new Runnable() {
            @Override
            public void run() {
                lock.c();
            }
        }).start();
    }


}
