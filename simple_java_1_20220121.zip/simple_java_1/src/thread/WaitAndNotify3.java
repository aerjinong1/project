package thread;

import javax.swing.plaf.IconUIResource;

public class WaitAndNotify3 {

    private boolean flag;
    private int count;


    public synchronized void addNum() {
        for (int i = 0; i < 26; i++) {
            while (flag) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println(++count);
            System.out.println(++count);
            flag = !flag;
            notify();
        }
    }


    public synchronized void addChar() {
        for (int i = 0; i < 26; i++) {
            while (!flag) {
                try {
                    wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println((char) (65 + i));
            flag = !flag;
            notify();
        }
    }

    public static void main(String[] args) {
        WaitAndNotify3 notify3 = new WaitAndNotify3();
        new Thread(new Runnable() {
            @Override
            public void run() {
                notify3.addNum();
            }
        }).start();

        new Thread().setName("A");

        new Thread(new Runnable() {
            @Override
            public void run() {
                notify3.addChar();
            }
        }).start();
    }
}

