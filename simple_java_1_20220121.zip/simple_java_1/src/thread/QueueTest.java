package thread;

//使用BlockingQueue改写当前的生产者消费者模型
public class QueueTest {

    public static int COUNT = 0;

    public static int FULL = 10;

    public final String LOCK = "abc";

    class Producer implements Runnable {

        @Override
        public void run() {
            for (int i = 0; i < 10; i++) {
                synchronized (LOCK) {
                    while (COUNT == FULL) {
                        try {
                            LOCK.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    System.out.println("producer------>" + Thread.currentThread().getName() + "----->" + (++COUNT));
                    LOCK.notifyAll();
                }

            }
        }
    }


    class Consumer implements Runnable {

        @Override
        public void run() {

            for (int i = 0; i < 10; i++) {
                synchronized (LOCK) {
                    while (COUNT == 0) {
                        try {
                            LOCK.wait();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    System.out.println("consumer------>" + Thread.currentThread().getName() + "------->" + (--COUNT));
                    LOCK.notifyAll();
                }
            }
        }
    }


    public static void main(String[] args) {
        QueueTest queueTest = new QueueTest();
        for (int i = 0; i < 3; i++) {
            new Thread(queueTest.new Producer()).start();
            new Thread(queueTest.new Consumer()).start();
        }
    }
}
