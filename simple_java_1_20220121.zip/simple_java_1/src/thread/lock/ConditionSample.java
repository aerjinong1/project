package thread.lock;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

public class ConditionSample implements Runnable {
    public static ReentrantLock lock = new ReentrantLock();
    public static Condition condition = lock.newCondition();

    @Override
    public void run() {
        try {
            lock.lock();
            condition.await();
            System.out.println("Thread going");
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            lock.unlock();
        }
    }


    public static void main(String[] args) throws InterruptedException {
        ConditionSample c1 = new ConditionSample();
        Thread t1 = new Thread(c1);
        t1.start();
        Thread.sleep(2000);
        lock.lock();
        //.....
        System.out.println("main thread go");
        condition.signal();
        lock.unlock();
    }
}
