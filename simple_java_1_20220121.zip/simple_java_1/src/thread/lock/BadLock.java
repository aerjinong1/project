package thread.lock;

import other.A;

public class  BadLock implements Runnable {

    public volatile static Integer i = 0;

    private static BadLock badLock = new BadLock();

    @Override
    public void run() {
        for (int j = 0; j < 10000000; j++) {
            synchronized (badLock) {
                i++;
                //i+=1;--->i=i+1;
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Thread t1 = new Thread(badLock);
        Thread t2 = new Thread(badLock);
        t1.start();
        t2.start();
        t1.join();
        t2.join();
        System.out.println(i);
    }

    public synchronized void test(){

    }

//    synchronized(this){
//        public void test(){
//
//        }
//    }
}
