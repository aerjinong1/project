package thread.lock;

import java.util.concurrent.Semaphore;

public class SemaphoreDemo {
    public static void main(String[] args) {
        Semaphore semaphore = new Semaphore(3);
        for (int i = 0; i < 10; i++) {
            new CatchDollThread("thread-" + i, semaphore).start();
        }
    }


    static class CatchDollThread extends Thread {
        private String name;
        private Semaphore semaphore;

        public CatchDollThread(String name, Semaphore semaphore) {
            this.name = name;
            this.semaphore = semaphore;
        }


        @Override
        public void run() {
            int permits = semaphore.availablePermits();
            if (permits > 0) {
                System.out.println(this.name + "you can do it");
            } else {
                System.out.println(this.name + "no");
            }

            try {
                semaphore.acquire();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(this.name + "start play!!!!!!" + "available permits:" + semaphore.availablePermits());
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(this.name + "leave");
            semaphore.release();
        }
    }
}
