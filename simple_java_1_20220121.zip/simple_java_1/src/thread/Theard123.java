package thread;

public class Theard123 extends Thread {

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName());
    }


    public static void main(String[] args) throws InterruptedException {
        Theard123 t1 = new Theard123();
        Theard123 t2 = new Theard123();
        Theard123 t3 = new Theard123();


        t1.start();
        t1.join();
        t2.start();
        t2.join();
        t3.start();
        t3.join();

    }
}
