package proxy.rpc;

import java.io.IOException;

public class Server {

    public static void main(String[] args) {
        try {
            //暴露服务
            HelloService service = new HelloServiceImpl();
            RpcFrameWork.export(service, 8989);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
