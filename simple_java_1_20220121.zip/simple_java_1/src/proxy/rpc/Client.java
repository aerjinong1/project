package proxy.rpc;

public class Client {

    public static void main(String[] args) {
//        HelloService service = new HelloServiceImpl();
//        service.hello();


        try {
            //引用服务
            HelloService service1 = RpcFrameWork.refer(HelloService.class, "127.0.0.1", 8989);
            for (int i = 0; i < Integer.MAX_VALUE; i++) {
                service1.hello();
//                System.out.println(hello);
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

