package proxy.rpc;

public interface HelloService {

    void hello();
}
