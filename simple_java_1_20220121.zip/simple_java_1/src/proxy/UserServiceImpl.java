package proxy;

/**
 * @author wei.jiang
 * @since 2018/11/23
 */
public class UserServiceImpl implements UserService {

    @Override
    public void add() {
//        System.out.println("aaaaa");
        System.out.println("--------------------add---------------");
//        System.out.println("bbbbb");
    }
}
