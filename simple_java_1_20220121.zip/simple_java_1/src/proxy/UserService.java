package proxy;

/**
 * @author wei.jiang
 * @since 2018/11/23
 */
public interface UserService {

    /**
     * 目标方法
     */
    void add();
}
