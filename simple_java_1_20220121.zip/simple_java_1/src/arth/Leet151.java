package arth;

public class Leet151 {
    public static void main(String[] args) {
        int[] a = {2,3,-2,4};
        System.out.println(maxProduct(a));
    }

    private static int maxProduct(int[] nums) {
        int max = 0;
        int res = 0;
        int current = 0;
        boolean currentChange = true;
        if (nums.length == 1) {
            return nums[0];
        }
        for (int i = current; i <= nums.length; i++) {
            if ((i - 1 == current || i == current) && currentChange) {
                res = nums[current];
                currentChange = false;
            } else if (i < nums.length) {
                res *= nums[i];
            }
            if (res > max || i == 0) {
                max = res;
            }
            if (i == nums.length - 1 && current < nums.length - 1) {
                current++;
                currentChange = true;
            }
        }
        return max;
    }
}
