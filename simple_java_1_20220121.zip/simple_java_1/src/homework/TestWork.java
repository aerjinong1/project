package homework;

import java.util.Scanner;

import static java.lang.Character.isLetter;

public class TestWork {


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String a = scanner.nextLine();
        char[] s = a.toCharArray();
        int i = 0;
        int j = s.length - 1;
        while (i < j ) {
            if (!isLetter(s[i])) {
                i++;
            } else if (!isLetter(s[j])) {
                j--;
            } else {
                char temp = s[i];
                s[i] = s[j];
                s[j] = temp;
                i++;
                j--;
            }
        }
        System.out.println(String.valueOf(s));
    }
}
