package queue.disruptor;

import com.lmax.disruptor.EventFactory;

public class PDataFactory implements EventFactory<PData> {
    @Override
    public PData newInstance() {
        return new PData();
    }
}
