package queue.disruptor;

public class PData {
    public long getData() {
        return data;
    }

    public void setData(long data) {
        this.data = data;
    }

    private long data;
}
