package variable;

public class VariableTest {

    //成员变量
    int memberVar = 6;

    //静态变量
    static int staticVar = 666;

    public void test(){
        //局部变量
        int localVar = 6666;
    }

}
