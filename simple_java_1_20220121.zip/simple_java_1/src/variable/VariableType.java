package variable;

public class VariableType {

    public static void main(String[] args) {
        short shortVar;
        int intVar;
        long longVar;
        float floatVar;
        double doubleVar;
        boolean booleanVar;
        char charVar;
        byte byteVar;
    }
}
