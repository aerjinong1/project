package generic;

/**
 * @author wei.jiang
 * @since 2018/10/31
 */
//T、E、K、V
public interface GenericInterface<T> {
    public T next();
}
