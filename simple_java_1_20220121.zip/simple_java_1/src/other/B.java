package other;

public class B {

    public String getA(A a) {
        a.setA("aa");
        return "B done";
    }
}
