package other;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class MainTest {
    public static void main(String[] args) {
//        A a = new A();
//        B b = new B();
//        b.getA(a);
//        C c = new C();
//        System.out.println(c.getA(a));
        List<LocalDate> list = new ArrayList<>();
        list.add(LocalDate.parse("2020-01-02"));
        list.add(LocalDate.parse("2020-01-03"));
        list.add(LocalDate.parse("2020-01-04"));
        list.add(LocalDate.parse("2020-01-05"));
        list.add(LocalDate.parse("2020-01-10"));
        list.add(LocalDate.parse("2020-01-11"));
        list.add(LocalDate.parse("2020-01-12"));
        list.add(LocalDate.parse("2020-01-19"));
        list.add(LocalDate.parse("2020-01-20"));

        List<LocalDate> stopList = list.stream().sorted(LocalDate::compareTo).collect(Collectors.toList());
        Map<LocalDate, LocalDate> stopMap = new HashMap<>();
        LocalDate stopStartDate = null;
        LocalDate stopEndDate = null;
        for (LocalDate mapper : stopList) {
            if (stopStartDate == null) {
                stopStartDate = mapper;
                continue;
            }
            if ((stopEndDate == null ? stopStartDate.plusDays(1) : stopEndDate.plusDays(1)).equals(mapper)) {
                stopEndDate = mapper;
                continue;
            } else {
                if (stopStartDate != null && stopEndDate != null) {
                    stopMap.put(stopStartDate, stopEndDate);
                    stopStartDate = mapper;
                    stopEndDate = null;
                    continue;
                }
            }

        }

        System.out.println(stopMap);
    }
}
