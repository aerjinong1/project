package other;

public class C {

    public String getA(A a) {
        return a.getA();
    }
}
