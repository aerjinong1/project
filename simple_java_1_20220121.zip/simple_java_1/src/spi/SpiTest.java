package spi;

import java.util.Iterator;
import java.util.ServiceLoader;

public class SpiTest {

    public static void main(String[] args) {
        ServiceLoader<SpiDemo> serviceLoader =
                ServiceLoader.load(SpiDemo.class);
        Iterator<SpiDemo> iterator = serviceLoader.iterator();
        while (iterator.hasNext()) {
            SpiDemo log = iterator.next();
            log.logInfo("JDK SPI");
        }
    }
}
