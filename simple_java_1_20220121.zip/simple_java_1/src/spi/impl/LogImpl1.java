package spi.impl;

import spi.SpiDemo;

public class LogImpl1 implements SpiDemo {
    @Override
    public void logInfo(String log) {
        System.out.println("log1:" + log);
    }
}
