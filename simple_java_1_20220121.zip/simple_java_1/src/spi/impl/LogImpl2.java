package spi.impl;

import spi.SpiDemo;

public class LogImpl2 implements SpiDemo {
    @Override
    public void logInfo(String log) {
        System.out.println("log2:" + log);
    }
}
