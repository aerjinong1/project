package spi;

public interface SpiDemo {

    void logInfo(String log);
}
