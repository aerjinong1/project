package method;

import oop.Person;

import java.util.Arrays;

public class MethodTest {

    private static final short SUCCESS = 1;

    private static final short ERROR = 0;


//    private static String aaa = "aaaaaaa";

//    private final static String BBB = "aaaaaaa";


    public int test1(String... args) {
        String aaa = "";
        Person person = new Person();
        int a = 1;
        System.out.println(Arrays.toString(args));
        return SUCCESS;

//        return args.length;
    }


    public static void main(String[] args) {
        MethodTest methodTest = new MethodTest();

        System.out.println(methodTest.test1("a", "b", "c", "d"));

        String name = AAAA.aaa.name();

        System.out.println(name);

        String[] a = {"a", "a", "a", "a", "a"};

        System.out.println(methodTest.test1(a));


        String str = "hello";
        System.out.println(str);
    }


    private enum AAAA {
        aaa,
        bbb;

    }
}
