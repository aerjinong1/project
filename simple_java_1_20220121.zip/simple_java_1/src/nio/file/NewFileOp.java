package nio.file;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

public class NewFileOp {
    public static void main(String[] args) throws IOException {
//        Path dir0 = Paths.get("/home");// 创建一个Path路径；Paths是工具类，用于产生Path
//        Files.createDirectory(dir0);// 创建单级目录；若已经存在 则抛出异常
//        Path dir1 = Paths.get("/home/jw/workspace/op_test/test1/test2/test.txt");
//        Files.createFile(dir1);// 创建文件；若目录没有 则抛出异常
//        Path dir2 = Paths.get("/home/jw/workspace/op_test/test1/test2");
//        Files.createDirectories(dir2);// 创建多级目录；若已经存在 不抛出异常
//
//
//        Path dir3 = Paths.get("/home/jw/workspace/test");
//        // 1.DirectoryStream可以理解成对于Path的Iterable，返回在dir3中符合第二个参数形式的Path集合
//        // 2.下面用到了一种try-with-resources的写法，该写法是在java1.7中引入的语法糖（极力推荐大家用该写法，因为它可以帮助你正确的关闭资源）
//        try (DirectoryStream<Path> stream = Files.newDirectoryStream(dir3,
//                "*.java")) {
//            for (Path entry : stream) {
//                System.out.println(entry.getFileName());
//            }
//        }


        Path source = Paths.get("/home/jw/workspace/op_test/test1/test2/test.txt");
        Path target = Paths.get("/home/jw/workspace/op_test/test1/test2/test1.txt");

        //以防乱码最好设置一下文件的编码格式，在StandardCharsets中有很多种内置编码格式
        List<String> list = Files.readAllLines(source, StandardCharsets.UTF_8);
        for (String s : list) {
            System.out.println(s);
        }
        //在StandardOpenOption中有很多种内置文件打开方式可供选择
//        List<String> writeList = new ArrayList<>();
//        writeList.add("11111");
//        writeList.add("22222");
//        writeList.add("33333");
        Files.write(target, list, StandardCharsets.UTF_8, StandardOpenOption.WRITE);
    }
}
