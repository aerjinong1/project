package nio.socket;

public interface NIOHandler {

    void handle();
}
