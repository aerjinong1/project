package oop;

public class StringTest {

    public static void main(String[] args) {
//        String s1 = "aaa";
//        String s2 = new String("aaa");
//        System.out.println(s1 == s2.intern());
        //造车
        buildCar();
    }

    public static void buildCar() {
        Wheel wheel = new Wheel();
        Car car = new Car();
        car.setWheel(wheel);
    }
}

class Wheel {

}

class Car {
    private Wheel wheel;

    public void setWheel(Wheel wheel) {
        this.wheel = wheel;
    }
}
