package oop;

import java.util.List;
import java.util.Map;

public class RunTest {

    public static A a2;

    //方法逃逸
    public A run1() {
        A a1 = new A();
        return a1;
    }

    //线程逃逸
    public void run2(A a2) {
        this.a2 = a2;
    }

    //无逃逸
    A a4 = new A();

    public void run3() {
        A a3 = new A();
        synchronized (a4) {
            System.out.println("aa");
        }
    }


}

class A {
    static int a = 10;

    static {
        System.out.println(a);
    }

    public A() {
        System.out.println("a");
    }
}

class Point {
    private int x; //标量
    private int y;
    private A a;
    private List<A> listA;
    private Map<String, A> map;

    public Point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    private static void alloc() {
//        Point p = new Point(1, 3);  //聚合量
        int x = 1;
        int y = 3;
        System.out.println(x + y);
//        System.out.println(p.x + p.y);
    }
}
