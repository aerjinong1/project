package oop;

import java.util.ArrayList;
import java.util.List;

public class StringTest1 {
//    public static String a = "a" + "asdafasdfasf";

    public static void main() {
        String b = "b";
//        String c = "aaa";
//        String d = b + c;
//        String e = b + "fff";
//
//        String x1 = new String("xxxxxxxx");
//        String x2 = new String("b");
//        String x3 = null;
//        System.out.println(b == x2);
//        x3 = x2.intern();
//        System.out.println(b == x3);
        String str = "abc";
        char[] arr = {'a', 'b', 'c'};
        String str2 = new String(arr);
        str2 = str2.intern();
        System.out.println(str == str2);
        List<String> list = new ArrayList<>();
        for (int i = 0; i < 1000000000; i++) {
            list.add(String.valueOf(i).intern());
        }
    }
}
