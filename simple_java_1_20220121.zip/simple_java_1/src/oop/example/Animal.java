package oop.example;

public class Animal {
    public String hand = "1";
    private int foot = 2;

    public Animal() {

    }

    public void eat() {
        System.out.println("------aoaoaooao");
    }

    public void sleep() {
        System.out.println("-------ssssssss");
    }


    public String sleep1() {
        return "-------ssssssss";
    }


    public int countLegs() {
        return foot;
    }
}
