package oop.example;

public abstract class TestAbstract {


    public abstract String testa();

    public String testb() {
        return "aasfdasdf";
    }
}
