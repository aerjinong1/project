package oop.example;

public interface TestInterface {

    String testab();

}
