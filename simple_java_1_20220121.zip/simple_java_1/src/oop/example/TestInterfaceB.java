package oop.example;

public interface TestInterfaceB {


    public String testB();
}
