package oop.example;

public class TestInteraceImplB2 implements TestInterface {
    @Override
    public String testab() {
        return "";
    }
}
