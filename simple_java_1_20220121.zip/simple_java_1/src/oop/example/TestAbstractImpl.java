package oop.example;

public class TestAbstractImpl extends TestAbstract {
    @Override
    public String testa() {
        return "bbbbb";
    }
}
