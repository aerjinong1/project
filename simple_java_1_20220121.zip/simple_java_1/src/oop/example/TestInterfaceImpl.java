package oop.example;

public class TestInterfaceImpl implements TestInterface,TestInterfaceB {
    @Override
    public String testab() {
        return "";
    }

    @Override
    public String testB() {
        return "";
    }
}
