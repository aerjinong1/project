package oop.example;

public class TestAbstractImplB extends TestAbstract {
    @Override
    public String testa() {
        return "cccccc";
    }
}
