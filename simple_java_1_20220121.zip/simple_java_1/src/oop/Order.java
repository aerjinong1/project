package oop;

import java.util.Date;

public class Order {

    private String id;

    private Integer uid;

    private String productId;

    private Date createTime;

    private Date updateTime;
}
