package oop;

public class MathTest {

    public static MathTest Test1 = new MathTest();


    public int compute() {
        int a = 1;
        int b = 1;
        return a + b;
//        return Test1.compute();
    }


    public static void main(String[] args) throws InterruptedException {
//        MathTest mathTest = new MathTest();
//        mathTest.compute();
        Test1.compute();

//        MathTest mathTest1 = new MathTest();
//        mathTest.compute();

        Thread.sleep(100000000);
        System.out.println("abc");
    }
}
