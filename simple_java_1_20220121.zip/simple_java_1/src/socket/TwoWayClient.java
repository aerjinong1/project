package socket;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

/**
 * @author wei.jiang
 * @since 2018/11/5
 */
public class TwoWayClient {
    public static void main(String args[]) throws Exception {
        try (
                // 实例化客户端,IO
                Socket socket = new Socket("localhost", 9000);
                // 输出信息给客户端
                OutputStream out = socket.getOutputStream();
                PrintWriter writer = new PrintWriter(out);
                // 接收客户端消息
                InputStream in = socket.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        ) {
            // 读取客户端的欢迎消息
//            String ret = reader.readLine();
//            System.out.println(ret);
            // 循环读取用户在Console输入的消息并写给服务端
            Scanner scanner = new Scanner(System.in);
//            BufferedReader systemIn = new BufferedReader(new InputStreamReader(System.in));
            while (true) {
                writer.println(scanner.nextLine());
                writer.flush();
                String ret = reader.readLine();
                System.out.println(ret);
                // 退出
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

//        Scanner sc = new Scanner(System.in);
//        System.out.println(sc.nextLine().getBytes());
    }
}
