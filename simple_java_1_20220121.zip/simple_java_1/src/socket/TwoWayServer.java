package socket;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author wei.jiang
 * @since 2018/11/5
 */
public class TwoWayServer {
    public static void main(String[] args) throws Exception {
        // 监听指定的端口
        int port = 9000;
        ServerSocket server = new ServerSocket(port);

        // server将一直等待连接的到来
        System.out.println("server将一直等待连接的到来");
        while (true){
            Socket socket = server.accept();
            // 建立好连接后，从socket中获取输入流，并建立缓冲区进行读取
//            InputStream inputStream = socket.getInputStream();
            InputStream in = socket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            String ret = reader.readLine();
            System.out.println("get message from client: " + ret);

            OutputStream outputStream = socket.getOutputStream();
            outputStream.write("Hello Client,I get the message.".getBytes("UTF-8"));
//            in.close();
//            outputStream.close();
        }



//        socket.close();
//        server.close();
    }
}
