package reflect;

/**
 * @author wei.jiang
 * @since 2018/11/23
 */
public interface USB {
    public void connection();//设备连接

    public void close();//设备断开
}
