package object_layout;

public class ClazzTest {

    public void foo(){
        a();
    }

    public void a(){

    }
}
