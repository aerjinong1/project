package object_layout;

public class HeapTest {
    public static void main(String[] args) {
        byte[] a1,a2;
        a1=new byte[7*1024*1024];
        System.getProperty("sun.boot.class.path");
    }
}
