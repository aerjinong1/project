package array;

public class TestArray {

    public static void main(String[] args) {
        int a[]=new int[5];
        for (int i = 0; i < 10; i++) {
            a[i]=1;
        }
    }
}
