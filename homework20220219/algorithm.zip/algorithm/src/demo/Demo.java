package demo;

public class Demo {

    int cal(int n) {
        int sum = 0;
        int i = 1;
        for (; i <= n; ++i) {
            sum = sum + i;
        }
        return sum;
    }


    int cal_1(int n) {
        int sum_1 = 0;
        int p = 1;
        for (; p < 100; ++p) {
            sum_1 = sum_1 + p;
        }
        int sum_2 = 0;
        int q = 1;
        for (; q < n; ++q) {
            sum_2 = sum_2 + q;
        }
        int sum_3 = 0;
        int i = 1;
        int j = 1;
        for (; i <= n; ++i) {
            j = 1;
            for (; j <= n; ++j) {
                sum_3 = sum_3 + i * j;
            }
        }
        return sum_1 + sum_2 + sum_3;
    }

    void cal_2(int n) {
        int ret = 0;
        int i = 1;
        for (; i < n; ++i) {
            ret = ret + f(i);
        }
    }

    int f(int n) {
        int sum = 0;
        int i = 1;
        for (; i < n; ++i) {
            sum = sum + i;
        }
        return sum;
    }

    void logn(int n) {
        int i = 1;
        while (i <= n) {
            i = i * 2;
        }
    }
//    int main(int argc, char* argv[]){
//        int i = 0;
//        int arr[3] = {0};
//        for(; i<=3; i++){
//            arr[i] = 0;
//            printf("hello world\n");
//        }
//        return 0;
//    }
int main() {
    int a = 1;
    int ret = 0;
    int res = 0;
    ret = add(3, 5);
    res = a + ret;
    System.out.printf("%d", res);
    return 0;
}
    int add(int x, int y) {
        int sum = 0;
        sum = x + y;
        return sum;
    }



}
